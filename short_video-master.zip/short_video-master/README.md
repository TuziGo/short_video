# HTML+CSS+JS实现短视频项目

<img width="100%" src="./imgs/cover.png">

## 在线教程
【HTML+CSS3+JS实现短视频项目】 https://www.bilibili.com/video/BV1xs4y1b7ug/?p=2&share_source=copy_web&vd_source=e3f0378c50b0ec66c10155eca2c0d212